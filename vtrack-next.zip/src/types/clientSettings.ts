type ClientSettings = {
  _id: string
  PropertyId: string
  clientId: string
  PropertyValue: string
  PropertDesc: string
  __v: number
  id: string
}
