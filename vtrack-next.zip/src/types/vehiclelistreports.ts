export type DeviceAttach = {
    true: boolean;
    IgnitionStatus: boolean;
    IsActive: boolean;
    Label1: string;
    clientId: string;
    currentDriverName: string;
    driverStatus: boolean;
    id: string;
    vehicleMake: string;
    vehicleModel: string;
    vehicleNo: string;
    vehicleReg: string;
    vehicleskipstep: number;
    __v: number;
    _id: string;
};
