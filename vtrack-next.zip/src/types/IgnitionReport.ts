export type IgnitionReport = {
    TimeZone: string;
    VehicleReg: string;
    clientId: string;
    fromDateTime: string;
    period: string;
    reportType: string;
    toDateTime: string;
    unit: string;
};
