export type zonelistType = {
    GeoFenceType: string;
    centerPoints: string;
    clientId: string;
    id: string;
    latlngCordinates: string;
    zoneName: string;
    zoneShortName: string;
    zoneType: string;
    
  };